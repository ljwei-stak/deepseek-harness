/** Browser lease for a host process started by the generated desktop shortcut. */
/** Start heartbeats when this page belongs to a shortcut-managed launch. */
export declare function startLauncherLifecycle(): () => void;
