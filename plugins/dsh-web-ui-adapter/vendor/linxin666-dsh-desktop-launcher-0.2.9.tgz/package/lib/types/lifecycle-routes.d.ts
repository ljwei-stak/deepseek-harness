/**
 * Loopback-only lifecycle lease for dsh processes started by the generated
 * desktop launcher. A launcher-scoped token prevents ordinary browser tabs
 * or unrelated local pages from controlling the host lifetime.
 */
import type { IncomingMessage } from 'node:http';
import type { WebRoute } from '@deepseek-ai/dsh-host-webserver';
/** Environment variable inherited by a shortcut-started dsh process. */
export declare const LAUNCHER_TOKEN_ENV = "DSH_DESKTOP_LAUNCHER_TOKEN";
/** Maximum silence accepted from one managed browser page. */
export declare const LIFECYCLE_LEASE_MS = 8000;
/** Reload/navigation grace before the final managed page closes the host. */
export declare const LIFECYCLE_RELEASE_GRACE_MS = 3000;
interface LifecycleClock {
    now(): number;
    schedule(fn: () => void, ms: number): unknown;
    cancel(handle: unknown): void;
}
export interface LauncherLifecycleDeps {
    token: string;
    requestExit(code: number): void;
    fence?: (request: IncomingMessage) => boolean;
    clock?: LifecycleClock;
}
export interface LauncherLifecycleRoute {
    route: WebRoute;
    dispose(): void;
}
/** Build the managed-browser lease route and its timer disposer. */
export declare function makeLauncherLifecycleRoute(deps: LauncherLifecycleDeps): LauncherLifecycleRoute;
export {};
